import { I, c } from "./mermaid-parser.core.ud-BjYfy.js";
export {
  I as InfoModule,
  c as createInfoServices
};
