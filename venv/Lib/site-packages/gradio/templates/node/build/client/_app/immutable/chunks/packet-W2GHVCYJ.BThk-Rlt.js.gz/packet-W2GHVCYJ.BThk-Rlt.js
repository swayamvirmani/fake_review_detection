import { P, a } from "./mermaid-parser.core.ud-BjYfy.js";
export {
  P as PacketModule,
  a as createPacketServices
};
