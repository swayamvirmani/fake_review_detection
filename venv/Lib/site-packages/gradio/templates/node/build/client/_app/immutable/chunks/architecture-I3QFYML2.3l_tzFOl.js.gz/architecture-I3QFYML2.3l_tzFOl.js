import { A, e } from "./mermaid-parser.core.ud-BjYfy.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
